const KEY = "amarOvertime_v4";
const LEGACY_KEYS = ["amarOvertime_v3", "amarOvertime_v2"];

function blankData() {
  return { activeWorkerId: 1, workers: [{ id: 1, name: "আমার হিসাব", settings: {} }], records: { 1: [] } };
}

function readData() {
  try {
    const current = JSON.parse(localStorage.getItem(KEY) || "null");
    if (current && Array.isArray(current.workers) && current.workers.length) return current;
    for (const legacyKey of LEGACY_KEYS) {
      const legacy = JSON.parse(localStorage.getItem(legacyKey) || "null");
      if (legacy && Array.isArray(legacy.workers) && legacy.workers.length) return migrateData(legacy);
    }
  } catch (e) {}
  return blankData();
}

function migrateData(old) {
  const next = {
    activeWorkerId: old.activeWorkerId || old.workers[0].id,
    workers: old.workers.map(w => ({ id: w.id, name: w.name || "Worker", settings: w.settings || {} })),
    records: {}
  };
  next.workers.forEach(w => {
    const list = (old.records && old.records[w.id]) || [];
    next.records[w.id] = list.map(r => {
      let dutyType = r.dutyType || "day";
      if (dutyType === "absence") dutyType = "absence";
      else if (dutyType === "leave") dutyType = "leave";
      else if (dutyType === "holiday") dutyType = "holiday";
      else if (dutyType === "night") dutyType = "night";
      else dutyType = "day";
      return {
        id: r.id || Date.now() + Math.random(),
        date: r.date,
        dutyType,
        status: dutyType === "absence" ? "absent" : dutyType === "leave" ? "leave" : dutyType === "holiday" ? "present" : (r.status || "present"),
        inTime: r.inTime || "",
        outTime: r.outTime || "",
        notes: r.notes || ""
      };
    });
  });
  return next;
}

let data = readData();
data.records = data.records || {};
data.workers.forEach(w => { if (!data.records[w.id]) data.records[w.id] = []; });
localStorage.setItem(KEY, JSON.stringify(data));

const $ = id => document.getElementById(id);
const activeWorker = () => data.workers.find(w => w.id === data.activeWorkerId) || data.workers[0];
const workerRecords = () => {
  const w = activeWorker();
  return data.records[w.id] || (data.records[w.id] = []);
};

function save() {
  localStorage.setItem(KEY, JSON.stringify(data));
  renderAll();
}

function todayLocal() {
  const d = new Date();
  const off = d.getTimezoneOffset();
  return new Date(d.getTime() - off * 60000).toISOString().slice(0, 10);
}

function money(n) { return "৳" + (Number(n) || 0).toFixed(2); }
function fmtHours(n) { return (Number(n) || 0).toFixed(2); }
function minutes(t) {
  if (!t) return 0;
  const p = t.split(":").map(Number);
  return p[0] * 60 + p[1];
}
function duration(a, b) {
  let x = minutes(a), y = minutes(b);
  if (y <= x) y += 1440;
  return Math.max(0, y - x);
}
function escapeHtml(s) {
  return String(s ?? "").replace(/[&<>\'"]/g, c => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", "\'": "&#39;", '"': "&quot;"
  }[c]));
}

function settings() {
  const saved = activeWorker().settings || {};
  return {
    salary: Number($("salary")?.value) || Number(saved.salary) || 0,
    salaryDays: Number($("salaryDays")?.value) || Number(saved.salaryDays) || 26,
    attendanceBonus: Number($("attendanceBonus")?.value) || Number(saved.attendanceBonus) || 625
  };
}

function loadSettings() {
  const s = activeWorker().settings || {};
  if ($("salary")) $("salary").value = s.salary ?? "15000";
  if ($("salaryDays")) $("salaryDays").value = s.salaryDays ?? "26";
  if ($("attendanceBonus")) $("attendanceBonus").value = s.attendanceBonus ?? "625";
}

function persistSettings() {
  activeWorker().settings = settings();
  localStorage.setItem(KEY, JSON.stringify(data));
  renderAll();
}

function dailyWage() {
  const s = settings();
  return s.salaryDays > 0 ? s.salary / s.salaryDays : 0;
}

function lateMinutes(r) {
  if (!r || (r.dutyType !== "day" && r.dutyType !== "night")) return 0;
  if (!r.inTime) return 0;
  const expected = r.dutyType === "day" ? 8 * 60 : 20 * 60;
  return Math.max(0, minutes(r.inTime) - expected);
}

function dayAllowance(r) {
  if (!r.inTime || !r.outTime || r.dutyType !== "day") return 0;
  // More than 15 minutes late means no allowance for that day.
  if (lateMinutes(r) > 15) return 0;

  let end = minutes(r.outTime);
  const start = minutes(r.inTime);
  if (end <= start) end += 1440;

  let allowance = 0;
  if (end >= 20 * 60) allowance += 100;
  if (end >= 22 * 60) allowance += 50;
  if (end >= 24 * 60) allowance += 50;
  return allowance;
}

function allowanceFor(r) {
  // Night Duty has no allowance in this version.
  if (r.dutyType === "day") return dayAllowance(r);
  return 0;
}

function lunchDeductionMinutes(r) {
  if (!r.inTime || !r.outTime || r.dutyType !== "day") return 0;
  let start = minutes(r.inTime);
  let end = minutes(r.outTime);
  if (end <= start) end += 1440;
  const lunchStart = 13 * 60;
  const lunchEnd = 14 * 60;
  return Math.max(0, Math.min(end, lunchEnd) - Math.max(start, lunchStart));
}

function calculate(r) {
  const s = settings();
  const wage = dailyWage();

  if (r.dutyType === "absence") {
    return { regularHours: 0, workedHours: 0, late: 0, allowance: 0, holidayWage: 0, dailyWage: wage, early: false };
  }
  if (r.dutyType === "leave" || r.status === "sick") {
    return { regularHours: 0, workedHours: 0, late: 0, allowance: 0, holidayWage: 0, dailyWage: wage, early: false };
  }
  if (r.dutyType === "holiday") {
    const worked = r.inTime && r.outTime ? duration(r.inTime, r.outTime) / 60 : 0;
    return { regularHours: 0, workedHours: worked, late: 0, allowance: 0, holidayWage: wage, dailyWage: wage, early: false };
  }
  if (!r.inTime || !r.outTime) {
    return { regularHours: 0, workedHours: 0, late: 0, allowance: 0, holidayWage: 0, dailyWage: wage, early: false };
  }

  const late = lateMinutes(r);
  const totalMinutes = duration(r.inTime, r.outTime);
  const lunch = lunchDeductionMinutes(r);
  const workedMinutes = Math.max(0, totalMinutes - lunch);
  const workedHours = workedMinutes / 60;

  let early = false;
  if (r.dutyType === "day") {
    let end = minutes(r.outTime);
    const start = minutes(r.inTime);
    if (end <= start) end += 1440;
    early = end < 17 * 60;
  }

  return {
    regularHours: workedHours,
    workedHours,
    late,
    allowance: allowanceFor(r),
    holidayWage: 0,
    dailyWage: wage,
    early
  };
}

function monthStats() {
  const s = settings();
  const ym = todayLocal().slice(0, 7);
  const rs = workerRecords().filter(r => String(r.date || "").startsWith(ym));

  let present = 0, absent = 0, leave = 0, sick = 0, holiday = 0;
  let regularHours = 0, workedHours = 0, late = 0, allowance = 0;
  let early = false;
  let lateDays = 0;

  rs.forEach(r => {
    const c = calculate(r);
    if (r.dutyType === "absence") absent++;
    else if (r.dutyType === "leave") leave++;
    else if (r.status === "sick") sick++;
    else if (r.dutyType === "holiday") holiday++;
    else present++;

    regularHours += c.regularHours;
    workedHours += c.workedHours;
    late += c.late;
    allowance += c.allowance;
    if (c.early) early = true;
    if (c.late >= 15) lateDays++;
  });

  const wage = dailyWage();
  const absenceDeduction = absent * wage;
  const lateGroupDays = Math.floor(lateDays / 3);
  const lateGroupDeduction = lateGroupDays * wage;
  const holidayWage = holiday * wage;

  // Attendance Bonus is lost at cumulative 15 late minutes, any early Day Duty,
  // or any Absence. Leave/Sick Leave do not cancel the bonus.
  const bonusLost = late >= 15 || early || absent > 0;
  const bonus = bonusLost ? 0 : s.attendanceBonus;

  const total = s.salary + holidayWage + allowance + bonus - absenceDeduction - lateGroupDeduction;

  return {
    rs, present, absent, leave, sick, holiday,
    regularHours, workedHours, late, allowance, early, lateDays,
    dailyWage: wage, absenceDeduction, lateGroupDays, lateGroupDeduction,
    holidayWage, bonus, bonusLost, total
  };
}

function stat(title, value, cls = "", primary = false) {
  return `<div class="stat ${primary ? "primary" : ""}"><small>${title}</small><strong class="${cls}">${value}</strong></div>`;
}

function renderDashboard() {
  const m = monthStats();
  const w = activeWorker();
  $("activeWorkerName").textContent = w.name;
  $("activeWorkerMeta").textContent = `${todayLocal().slice(0, 7)} • মাসিক হিসাব`;
  $("dashboard").innerHTML = [
    stat("এই মাসের মোট বেতন", money(m.total), "", true),
    stat("Present", m.present),
    stat("Absent", m.absent, m.absent ? "bad" : ""),
    stat("Leave", m.leave),
    stat("Sick Leave", m.sick),
    stat("Holiday", m.holiday),
    stat("Worked Hours", fmtHours(m.workedHours)),
    stat("Holiday Wage", money(m.holidayWage)),
    stat("Allowance", money(m.allowance)),
    stat("Late Minutes", `${m.late} min`, m.late >= 15 ? "bad" : ""),
    stat("Late Days (≥15m)", m.lateDays),
    stat("Late Deduction", money(m.lateGroupDeduction), m.lateGroupDeduction ? "bad" : ""),
    stat("Attendance Bonus", money(m.bonus), m.bonus ? "ok" : "bad")
  ].join("");
}

function dutyLabel(r) {
  return ({ day: "🌞 Day Duty", night: "🌙 Night Duty", holiday: "🎉 Holiday Duty", absence: "❌ Absence", leave: "📄 Leave" }[r.dutyType] || "Day Duty");
}

function renderToday() {
  const r = workerRecords().find(x => x.date === todayLocal());
  if (!r) {
    $("todayCard").innerHTML = '<div class="empty">আজকের কোনো রেকর্ড সেভ করা হয়নি।</div>';
    return;
  }
  const c = calculate(r);
  $("todayCard").innerHTML = `<div class="today-row"><div><strong>${dutyLabel(r)}</strong><br><span class="badge ${r.dutyType}">${escapeHtml(r.status || "-")}</span></div><div><b>Allowance ${money(c.allowance)}</b><br><small>${r.inTime || "-"} → ${r.outTime || "-"}${c.holidayWage ? ` • Holiday Wage ${money(c.holidayWage)}` : ""}</small></div></div>`;
}

function renderRecent() {
  const rs = workerRecords().slice().sort((a, b) => String(b.date).localeCompare(String(a.date))).slice(0, 5);
  $("recentRecords").innerHTML = rs.length ? rs.map(r => {
    const c = calculate(r);
    return `<div class="record-row"><div><b>${escapeHtml(r.date)}</b><br><small>${dutyLabel(r)}</small></div><div><b>${money(c.allowance)}</b><br><small>${c.holidayWage ? `Holiday Wage ${money(c.holidayWage)}` : "Allowance"}</small></div></div>`;
  }).join("") : '<div class="empty">এখনও কোনো রেকর্ড নেই।</div>';
}

function renderRecords() {
  const q = ($("recordSearch").value || "").toLowerCase();
  let rs = workerRecords().slice().sort((a, b) => String(b.date).localeCompare(String(a.date)));
  if (q) rs = rs.filter(r => `${r.date} ${r.dutyType} ${r.status || ""} ${r.notes || ""}`.toLowerCase().includes(q));
  $("recordCount").textContent = `${rs.length}টি রেকর্ড`;
  $("records").innerHTML = rs.map(r => {
    const c = calculate(r);
    return `<tr>
      <td>${escapeHtml(r.date)}</td>
      <td>${dutyLabel(r)}</td>
      <td>${escapeHtml(r.status || "-")}</td>
      <td>${r.inTime || "-"}</td>
      <td>${r.outTime || "-"}</td>
      <td>${fmtHours(c.workedHours)}</td>
      <td>${c.late}</td>
      <td>${money(c.allowance)}</td>
      <td>${money(c.holidayWage)}</td>
      <td>${c.early ? "Yes" : "-"}</td>
      <td><button class="mini secondary" onclick="editRecord(${r.id})">Edit</button> <button class="mini danger" onclick="deleteRecord(${r.id})">Delete</button></td>
    </tr>`;
  }).join("") || '<tr><td colspan="11" class="empty">কোনো রেকর্ড পাওয়া যায়নি।</td></tr>';
}

function renderWorkers() {
  $("workerList").innerHTML = data.workers.map(w => `<div class="worker-item"><div><b>${escapeHtml(w.name)}</b><div class="meta">${w.id === data.activeWorkerId ? "✓ Active Worker" : ""}</div></div><div class="worker-actions"><button onclick="selectWorker(${w.id})">${w.id === data.activeWorkerId ? "Active" : "Select"}</button>${data.workers.length > 1 ? `<button class="danger" onclick="deleteWorker(${w.id})">Delete</button>` : ""}</div></div>`).join("");
}

function renderAll() {
  loadSettings();
  renderDashboard();
  renderToday();
  renderRecent();
  renderRecords();
  renderWorkers();
}

function showPage(id) {
  document.querySelectorAll(".page").forEach(p => p.classList.toggle("active", p.id === id));
  document.querySelectorAll(".nav-item").forEach(b => b.classList.toggle("active", b.dataset.page === id));
  window.scrollTo(0, 0);
}

function toast(msg) {
  const t = $("toast");
  t.textContent = msg;
  t.classList.add("show");
  clearTimeout(window._toast);
  window._toast = setTimeout(() => t.classList.remove("show"), 2200);
}

function setDefaults() {
  if ($("date")) $("date").value = todayLocal();
  if ($("dutyType")) $("dutyType").value = "day";
  if ($("status")) $("status").value = "present";
  if ($("inTime")) $("inTime").value = "08:00";
  if ($("outTime")) $("outTime").value = "17:00";
  applyDutyDefaults();
}

function applyDutyDefaults() {
  const type = $("dutyType").value;
  if (type === "day") {
    $("inTime").value = "08:00"; $("outTime").value = "17:00"; $("status").value = "present";
    $("timeHelp").textContent = "Day Duty: 8:00 AM → 5:00 PM. 1:00 PM → 2:00 PM lunch ১ ঘণ্টা deduction. 5 PM-এর পর allowance: 8 PM = ৳100, 10 PM = +৳50, 12 AM = +৳50.";
  } else if (type === "night") {
    $("inTime").value = "20:00"; $("outTime").value = "04:00"; $("status").value = "present";
    $("timeHelp").textContent = "Night Duty: 8:00 PM → 4:00 AM. কোনো break deduction নেই. Night Duty-তে কোনো allowance নেই.";
  } else if (type === "holiday") {
    $("inTime").value = "08:00"; $("outTime").value = "17:00"; $("status").value = "present";
    $("timeHelp").textContent = "Holiday Duty: কোনো fixed time নেই. যত ঘণ্টাই কাজ করুন, এই দিনের জন্য ১টি পূর্ণ অতিরিক্ত হাজিরা wage যোগ হবে. কোনো allowance নেই.";
  } else if (type === "absence") {
    $("inTime").value = ""; $("outTime").value = ""; $("status").value = "absent";
    $("timeHelp").textContent = "Absence: ওই দিনের ১ দিনের wage কাটা হবে এবং Attendance Bonus বাতিল হবে.";
  } else if (type === "leave") {
    $("inTime").value = ""; $("outTime").value = ""; $("status").value = "leave";
    $("timeHelp").textContent = "Leave: মাসিক বেতনে কোনো হাজিরা deduction নেই এবং Leave হিসেবে গণনা হবে.";
  }
}

$("dutyType").addEventListener("change", applyDutyDefaults);

$("dutyForm").addEventListener("submit", e => {
  e.preventDefault();
  const dutyType = $("dutyType").value;
  if ((dutyType === "day" || dutyType === "night" || dutyType === "holiday") && (!$("inTime").value || !$("outTime").value)) {
    toast("In Time এবং Out Time দিন");
    return;
  }

  const r = {
    id: Date.now(),
    date: $("date").value,
    dutyType,
    status: dutyType === "absence" ? "absent" : dutyType === "leave" ? "leave" : dutyType === "holiday" ? "present" : $("status").value,
    inTime: $("inTime").value,
    outTime: $("outTime").value,
    notes: $("notes").value.trim()
  };

  const rs = workerRecords();
  const index = rs.findIndex(x => x.date === r.date);
  if (index >= 0) rs[index] = r; else rs.push(r);
  rs.sort((a, b) => String(a.date).localeCompare(String(b.date)));
  save();
  $("notes").value = "";
  setDefaults();
  toast("রেকর্ড সেভ হয়েছে");
  showPage("homePage");
});

$("clearBtn").onclick = () => { $("dutyForm").reset(); setDefaults(); };
$("recordSearch").addEventListener("input", renderRecords);
["salary", "salaryDays", "attendanceBonus"].forEach(id => $(id).addEventListener("input", persistSettings));

$("addWorkerBtn").onclick = () => {
  const name = $("workerName").value.trim();
  if (!name) return toast("Worker-এর নাম দিন");
  const id = Date.now();
  data.workers.push({ id, name, settings: {} });
  data.records[id] = [];
  data.activeWorkerId = id;
  $("workerName").value = "";
  save();
  toast("Worker যোগ হয়েছে");
};

window.selectWorker = id => { data.activeWorkerId = id; save(); toast("Active Worker পরিবর্তন হয়েছে"); showPage("homePage"); };
window.deleteWorker = id => {
  if (data.workers.length <= 1) return toast("কমপক্ষে একজন Worker থাকতে হবে");
  if (!confirm("এই Worker এবং তার সব record মুছবেন?")) return;
  data.workers = data.workers.filter(w => w.id !== id);
  delete data.records[id];
  data.activeWorkerId = data.workers[0].id;
  save();
};

window.editRecord = id => {
  const r = workerRecords().find(x => x.id === id);
  if (!r) return;
  $("date").value = r.date;
  $("dutyType").value = r.dutyType;
  $("status").value = r.status || "present";
  $("inTime").value = r.inTime || "";
  $("outTime").value = r.outTime || "";
  $("notes").value = r.notes || "";
  data.records[activeWorker().id] = workerRecords().filter(x => x.id !== id);
  localStorage.setItem(KEY, JSON.stringify(data));
  showPage("dutyPage");
  $("timeHelp").textContent = "Edit mode: পরিবর্তন করে Save করুন.";
};

window.deleteRecord = id => {
  if (confirm("এই record মুছবেন?")) {
    data.records[activeWorker().id] = workerRecords().filter(x => x.id !== id);
    save();
    toast("Record মুছে ফেলা হয়েছে");
  }
};

$("clearAllBtn").onclick = () => {
  if (confirm("এই Worker-এর সব record মুছবেন?")) {
    data.records[activeWorker().id] = [];
    save();
    toast("সব record মুছে গেছে");
  }
};

function downloadNative(content, fileName, mime) {
  const bytes = new TextEncoder().encode(content);
  let binary = "";
  bytes.forEach(b => binary += String.fromCharCode(b));
  const base64 = btoa(binary);
  if (window.AndroidApp && AndroidApp.saveFile) AndroidApp.saveFile(base64, fileName, mime);
  else {
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([content], { type: mime }));
    a.download = fileName;
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  }
}

$("exportBtn").onclick = () => {
  const rows = [["Date", "Duty Type", "Status", "In", "Out", "Worked Hours", "Late Minutes", "Allowance", "Holiday Wage", "Early Leave", "Notes"]];
  workerRecords().forEach(r => {
    const c = calculate(r);
    rows.push([r.date, r.dutyType, r.status, r.inTime, r.outTime, c.workedHours.toFixed(2), c.late, c.allowance, c.holidayWage, c.early ? "Yes" : "No", r.notes || ""]);
  });
  const csv = "\ufeff" + rows.map(row => row.map(v => `"${String(v ?? "").replaceAll('"', '""')}"`).join(",")).join("\n");
  downloadNative(csv, "amar-overtime-records.csv", "text/csv;charset=utf-8");
  toast("CSV export করা হয়েছে");
};

$("backupBtn").onclick = () => downloadNative(JSON.stringify(data, null, 2), "amar-overtime-backup.json", "application/json");
$("restoreBtn").onclick = () => {
  if (window.AndroidApp && AndroidApp.openBackup) AndroidApp.openBackup();
  else toast("Android app থেকেই Restore করুন");
};

window.importBackup = json => {
  try {
    const incoming = JSON.parse(json);
    if (!Array.isArray(incoming.workers) || !incoming.workers.length || !incoming.records) throw new Error("invalid");
    data = incoming;
    localStorage.setItem(KEY, JSON.stringify(data));
    renderAll();
    toast("Backup সফলভাবে Restore হয়েছে");
  } catch (e) {
    toast("Backup ফাইলটি সঠিক নয়");
  }
};

$("quickWorkerBtn").onclick = () => showPage("settingsPage");
document.querySelectorAll("[data-page]").forEach(b => b.addEventListener("click", () => showPage(b.dataset.page)));

function tick() {
  $("clock").textContent = new Date().toLocaleString("bn-BD", { dateStyle: "medium", timeStyle: "short" });
}
setInterval(tick, 1000);
tick();
setDefaults();
renderAll();
