# আমার ওভার টাইম — Allowance-only Android App

Developer: **BORHAN**  
Application ID: `com.borhan.amarot`  
Version: **3.0**

## এই Version-এর মূল নিয়ম

- **কোনো OT নেই।** OT Hours, OT Rate বা OT Wage কোথাও গণনা করা হয় না।
- **🌞 Day Duty:** 8:00 AM → 5:00 PM
  - 1:00 PM → 2:00 PM = 1 ঘণ্টা lunch deduction
  - 8:00 PM পর্যন্ত/পরে কাজ করলে allowance = ৳100
  - 10:00 PM পর্যন্ত/পরে = মোট ৳150
  - 12:00 AM পর্যন্ত/পরে = মোট ৳200
- **🌙 Night Duty:** 8:00 PM → 4:00 AM
  - কোনো break deduction নেই
  - Night Duty-তে **কোনো allowance নেই**
- **🎉 Holiday Duty:** কোনো fixed time limit নেই
  - যত ঘণ্টাই কাজ করা হোক, ওই দিনের জন্য **১ দিনের পূর্ণ Attendance Wage** অতিরিক্ত যোগ হবে
  - Holiday Duty-তে কোনো allowance নেই
- **❌ Absence:** ওই দিনের ১ দিনের wage কাটা হবে এবং পুরো মাসের Attendance Bonus বাতিল হবে
- **📄 Leave:** salary থেকে attendance deduction নেই; Leave হিসেবে গণনা হবে
- **Sick Leave:** Sick Leave হিসেবে গণনা হবে; salary deduction করা হয় না
- কোনো Day/Night duty-তে **15 মিনিটের বেশি late** হলে ওই দিনের allowance = ৳0
- মাসের cumulative late **15 মিনিটে পৌঁছালে** Attendance Bonus = ৳0
- Day Duty-তে **5 PM-এর আগে বের হলে** Attendance Bonus = ৳0
- **15 মিনিট বা তার বেশি late হওয়া ৩টি দিন = ১ দিনের wage deduction**
- ৬টি late day = ২ দিনের wage deduction, ইত্যাদি
- Attendance Bonus = **৳625** (Settings থেকে পরিবর্তনযোগ্য)
- Daily Attendance Wage = **Monthly Salary ÷ Working Days**

## Monthly total

`Monthly Salary + Holiday Wage + Allowance + Attendance Bonus - Absence Deduction - Late Group Deduction`

## Features

- Day / Night / Holiday / Absence / Leave
- Sick Leave status
- Monthly salary input
- Automatic holiday attendance wage
- Monthly total salary calculation
- Present / Absent / Leave / Sick Leave / Holiday dashboard
- Daily records
- Edit / Delete
- Monthly dashboard
- Current date/time
- CSV export
- JSON Backup / Restore
- Multiple Worker profiles
- Browser localStorage / offline-first data storage

## GitHub Actions

The repository contains `.github/workflows/android.yml`.

If you upload the **contents of this ZIP** to the repository root, GitHub Actions will build the Debug APK automatically on push to `main` or `master`.

The workflow also contains a fallback: if the repository has no `settings.gradle` at the root but contains a project ZIP, it will try to extract the ZIP and build it. However, for the most reliable setup, **extract this ZIP and upload its contents to the repository root** rather than uploading the ZIP as the only file.

### APK

After the workflow succeeds, open the GitHub Actions run and download the artifact named:

`AmarOvertime-debug-apk`

## Build configuration

- compileSdk 36
- targetSdk 36
- minSdk 23
- Java 17
- Gradle 8.2.1
- Android Gradle Plugin 8.2.2

## Privacy

The app is offline-first. Duty records, worker profiles and salary settings are stored locally in browser/WebView local storage. CSV/JSON export is user-controlled.
